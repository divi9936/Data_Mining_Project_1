
**Instruction for running the code**

-->There are in total 3 jupyter notebooks, each for decision tree, random forest and neural networks with their names specified.
--> The new dataset that i have implemented will automatically be created by the code.

** References for the code**

--> https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html
--> https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html
--> https://scikit-learn.org/stable/modules/generated/sklearn.neural_network.MLPClassifier.html
--> https://medium.com/swlh/post-pruning-decision-trees-using-python-b5d4bcda8e23
--> https://machinelearningmastery.com/generate-test-datasets-python-scikit-learn/

**-------------------------------------**---------------------------------**----------------------------------------------**-----------------------------------------
